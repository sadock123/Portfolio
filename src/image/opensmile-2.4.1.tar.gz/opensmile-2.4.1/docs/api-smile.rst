opensmile
=========

config
------

.. autoclass:: opensmile.config
    :members:

FeatureLevel
------------

.. autoclass:: opensmile.FeatureLevel
    :members:

FeatureSet
----------

.. autoclass:: opensmile.FeatureSet
    :members:

Smile
-----

.. autoclass:: opensmile.Smile
    :members:
    :inherited-members:

    .. automethod:: __call__
